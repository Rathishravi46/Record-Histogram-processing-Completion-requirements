# Ex. No: 03 
## Histogram Equalization Using OpenCV (Grayscale & Color Images)

**Name :  RATHISH R    **Reg. No :** 212224240132  **Slot No :260D1143

### Write a Python program using OpenCV to perform histogram equalization on the given grayscale image **"parrot.jpg"**.

The program should:

- Import the required libraries (**OpenCV, NumPy, Matplotlib**).
- Read the image **"parrot.jpg"** in **grayscale** format.
- Display the grayscale image and plot its histogram.
- Perform **histogram equalization** on the grayscale image using `cv2.equalizeHist()` to enhance its contrast.
- Using Matplotlib, display the following in a **2 × 2 grid layout**:
  - Original Grayscale Image
  - Histogram of Original Image
  - Enhanced (Equalized) Image
  - Histogram of Enhanced Image



```python
import cv2
import numpy as np
import matplotlib.pyplot as plt
```


```python
img = cv2.imread('parrot.jpg', cv2.IMREAD_GRAYSCALE)

```


```python

plt.imshow(img, cmap='gray')
plt.title('Original Image')
plt.show()

```


    
![png](output_4_0.png)
    



```python

plt.hist(img.ravel(),256,range = [0, 256]);
plt.title('Original Image')
plt.show()


```


    
![png](output_5_0.png)
    



```python
img_eq = cv2.equalizeHist(img)
```


```python
plt.hist(img_eq.ravel(), 256, range = [0, 256])
plt.title('Equalized Histogram')
```




    Text(0.5, 1.0, 'Equalized Histogram')




    
![png](output_7_1.png)
    



```python
plt.imshow(img_eq, cmap='gray')
plt.title('Original Image')
plt.show()
```


    
![png](output_8_0.png)
    


### Write a Python program using OpenCV to perform color image enhancement through histogram equalization in the HSV color space on the given image **"parrot.jpg"**.

The program should:

- Import the required libraries (**OpenCV, NumPy, Matplotlib**).
- Read the color image **"parrot.jpg"**.
- Plot the **histogram of the original color image** (use the **B, G, and R** channels).
- Convert the image from **BGR to HSV** color space.
- Apply **histogram equalization** to one specific channel to improve brightness and contrast using `cv2.equalizeHist()`.
- Convert the enhanced HSV image back to **BGR** format.
- Using Matplotlib, display the following in a **2 × 2 grid layout**:
  - Original Color Image
  - Histogram of Original Image (BGR channels)
  - Enhanced Color Image
  - Histogram of Enhanced Image (BGR channels)



```python

img = cv2.imread('parrot.jpg', cv2.IMREAD_COLOR)


```


```python
img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)




```


```python
img_hsv[:,:,2] = cv2.equalizeHist(img_hsv[:, :, 2])




```


```python
img_eq = cv2.cvtColor(img_hsv, cv2.COLOR_HSV2BGR)




```


```python
plt.imshow(img_eq[:,:,::-1]); plt.title('Equalized Image');plt.show()




```


    
![png](output_14_0.png)
    



```python
# Convert back to BGR format
plt.hist(img_eq.ravel(),256,range = [0, 256]); plt.title('Histogram Equalized');plt.show()



```


    
![png](output_15_0.png)
    



```python

#plt.figure(figsize = (20,10))
plt.subplot(221); plt.imshow(img[:, :, ::-1]); plt.title('Original Color Image')
plt.subplot(222); plt.imshow(img_eq[:, :, ::-1]); plt.title('Equalized Image')
plt.subplot(223); plt.hist(img.ravel(),256,range = [0, 256]); plt.title('Original Image')
plt.subplot(224); plt.hist(img_eq.ravel(),256,range = [0, 256]); plt.title('Histogram Equalized');plt.show()



```


    
![png](output_16_0.png)
    



```python

plt.figure(figsize = [15,4])
plt.subplot(121); plt.hist(img.ravel(),256,range = [0, 256]); plt.title('Original Image')
plt.subplot(122); plt.hist(img_eq.ravel(),256,range = [0, 256]); plt.title('Histogram Equalized')
```




    Text(0.5, 1.0, 'Histogram Equalized')




    
![png](output_17_1.png)
    



```python

```
